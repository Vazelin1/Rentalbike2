package com.ebikerent.app.ui.renters

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.data.RenterEntity
import com.ebikerent.app.ui.theme.StatusColors
import com.ebikerent.app.util.CurrencyUtils
import com.ebikerent.app.util.DateUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RentersScreen(repository: AppRepository, onOpenRenter: (Long) -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    val renters by (if (query.isBlank()) repository.observeRenters() else repository.searchRenters(query))
        .collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Арендаторы") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить арендатора")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                placeholder = { Text("Поиск по ФИО") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )
            if (renters.isEmpty()) {
                Box(Modifier.fillMaxSize()) { Text("Арендаторов не найдено", modifier = Modifier.padding(16.dp)) }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(renters, key = { it.id }) { renter ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onOpenRenter(renter.id) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (renter.problematic) StatusColors.ProblematicBg
                                else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(renter.fullName, fontWeight = FontWeight.Bold)
                                if (renter.phone.isNotBlank()) Text(renter.phone)
                                if (renter.problematic) Text("⚠ Проблемный клиент", color = StatusColors.Overdue)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddRenterDialog(
            onConfirm = { fullName, phone, comment, problematic ->
                scope.launch {
                    repository.addRenter(
                        RenterEntity(fullName = fullName, phone = phone, comment = comment, problematic = problematic)
                    )
                }
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun AddRenterDialog(
    onConfirm: (String, String, String, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var problematic by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый арендатор") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("ФИО") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Комментарий") }, modifier = Modifier.fillMaxWidth())
                Row {
                    Checkbox(checked = problematic, onCheckedChange = { problematic = it })
                    Text("Проблемный клиент", modifier = Modifier.padding(top = 12.dp))
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(fullName, phone, comment, problematic) },
                enabled = fullName.isNotBlank()
            ) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RenterDetailScreen(repository: AppRepository, renterId: Long, onBack: () -> Unit) {
    val renter by repository.observeRenter(renterId).collectAsState(initial = null)
    val rentals by repository.observeRentalsForRenter(renterId).collectAsState(initial = emptyList())
    val totalPaid by repository.observeTotalPaidByRenter(renterId).collectAsState(initial = 0.0)
    val rentalCount by repository.observeRentalCountForRenter(renterId).collectAsState(initial = 0)
    val lastRentalDate by repository.observeLastRentalDateForRenter(renterId).collectAsState(initial = null)

    val r = renter ?: run {
        Scaffold(topBar = { TopAppBar(title = { Text("Арендатор") }) }) { p -> Box(Modifier.padding(p)) }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(r.fullName) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (r.problematic) {
                Card(colors = CardDefaults.cardColors(containerColor = StatusColors.ProblematicBg)) {
                    Text("⚠ Проблемный клиент", modifier = Modifier.padding(12.dp), color = StatusColors.Overdue, fontWeight = FontWeight.Bold)
                }
            }
            Text("Телефон: ${r.phone.ifBlank { "—" }}")
            if (r.comment.isNotBlank()) Text("Комментарий: ${r.comment}")

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Всего оплачено: ${CurrencyUtils.formatRub(totalPaid ?: 0.0)}", fontWeight = FontWeight.Bold)
                    Text("Количество аренд: $rentalCount")
                    Text("Последняя аренда: ${lastRentalDate?.let { DateUtils.formatDate(it) } ?: "—"}")
                }
            }

            Text("История аренд", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            if (rentals.isEmpty()) {
                Text("Аренд ещё не было")
            } else {
                rentals.forEach { rental ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${DateUtils.formatDate(rental.startDate)} — ${DateUtils.formatDate(rental.endDate)}")
                            Text("Сумма: ${CurrencyUtils.formatRub(rental.price)}")
                            if (!rental.active) Text("Завершена", color = StatusColors.Unused)
                        }
                    }
                }
            }
        }
    }
}
