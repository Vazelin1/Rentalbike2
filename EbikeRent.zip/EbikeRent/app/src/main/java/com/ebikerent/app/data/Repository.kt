package com.ebikerent.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class AppRepository(private val db: AppDatabase) {

    private val bikeDao = db.bikeDao()
    private val renterDao = db.renterDao()
    private val repairDao = db.repairDao()
    private val rentalDao = db.rentalDao()
    private val extensionDao = db.rentalExtensionDao()
    private val photoDao = db.rentalPhotoDao()
    private val bikePhotoDao = db.bikePhotoDao()
    private val settingsDao = db.appSettingsDao()

    // ---------- Bikes ----------
    fun observeBikes(): Flow<List<BikeEntity>> = bikeDao.observeAll()
    fun observeFreeBikes(): Flow<List<BikeEntity>> = bikeDao.observeByStatus(BikeStatus.FREE)
    fun observeBike(id: Long): Flow<BikeEntity?> = bikeDao.observeById(id)
    suspend fun getBike(id: Long): BikeEntity? = bikeDao.getById(id)
    suspend fun addBike(bike: BikeEntity): Long = bikeDao.insert(bike)
    suspend fun updateBike(bike: BikeEntity) = bikeDao.update(bike)
    suspend fun deleteBike(bike: BikeEntity) = bikeDao.delete(bike)

    fun observeBikeCount(): Flow<Int> = bikeDao.observeCount()
    fun observeBikeCountByStatus(status: BikeStatus): Flow<Int> = bikeDao.observeCountByStatus(status)

    // ---------- Renters ----------
    fun observeRenters(): Flow<List<RenterEntity>> = renterDao.observeAll()
    fun searchRenters(query: String): Flow<List<RenterEntity>> = renterDao.search(query)
    fun observeRenter(id: Long): Flow<RenterEntity?> = renterDao.observeById(id)
    suspend fun getRenter(id: Long): RenterEntity? = renterDao.getById(id)
    suspend fun addRenter(renter: RenterEntity): Long = renterDao.insert(renter)
    suspend fun updateRenter(renter: RenterEntity) = renterDao.update(renter)

    // ---------- Repairs ----------
    fun observeRepairsForBike(bikeId: Long): Flow<List<RepairEntity>> = repairDao.observeForBike(bikeId)
    fun observeRepairCostForBike(bikeId: Long): Flow<Double?> = repairDao.observeTotalCostForBike(bikeId)
    fun observeTotalRepairCost(): Flow<Double?> = repairDao.observeTotalCost()
    suspend fun addRepair(repair: RepairEntity): Long = repairDao.insert(repair)

    // ---------- Rentals ----------
    fun observeActiveRentals(): Flow<List<RentalEntity>> = rentalDao.observeActive()
    fun observeRentalsForBike(bikeId: Long): Flow<List<RentalEntity>> = rentalDao.observeForBike(bikeId)
    fun observeRentalsForRenter(renterId: Long): Flow<List<RentalEntity>> = rentalDao.observeForRenter(renterId)
    fun observeRental(id: Long): Flow<RentalEntity?> = rentalDao.observeById(id)
    suspend fun getRental(id: Long): RentalEntity? = rentalDao.getById(id)

    fun observeReceivedForBike(bikeId: Long): Flow<Double?> = rentalDao.observeTotalReceivedForBike(bikeId)
    fun observeTotalReceived(): Flow<Double?> = rentalDao.observeTotalReceived()
    fun observeRentalCountForBike(bikeId: Long): Flow<Int> = rentalDao.observeCountForBike(bikeId)
    fun observeTotalPaidByRenter(renterId: Long): Flow<Double?> = rentalDao.observeTotalPaidByRenter(renterId)
    fun observeRentalCountForRenter(renterId: Long): Flow<Int> = rentalDao.observeCountForRenter(renterId)
    fun observeLastRentalDateForRenter(renterId: Long): Flow<Long?> = rentalDao.observeLastRentalDateForRenter(renterId)
    fun observeLastRentalDateForBike(bikeId: Long): Flow<Long?> = rentalDao.observeLastRentalDateForBike(bikeId)

    /** Создать новую аренду: занимает велосипед. */
    suspend fun createRental(rental: RentalEntity): Long {
        val id = rentalDao.insert(rental)
        val bike = bikeDao.getById(rental.bikeId)
        if (bike != null) {
            bikeDao.update(bike.copy(status = BikeStatus.RENTED))
        }
        return id
    }

    suspend fun updateRental(rental: RentalEntity) = rentalDao.update(rental)

    /** Продлить аренду: новая дата окончания + доп. оплата, запись в историю продлений. */
    suspend fun extendRental(rentalId: Long, newEndDate: Long, paymentAmount: Double) {
        val rental = rentalDao.getById(rentalId) ?: return
        val updated = rental.copy(
            endDate = newEndDate,
            price = rental.price + paymentAmount,
            amountPaid = rental.amountPaid + paymentAmount
        )
        rentalDao.update(updated)
        extensionDao.insert(
            RentalExtensionEntity(
                rentalId = rentalId,
                date = System.currentTimeMillis(),
                newEndDate = newEndDate,
                paymentAmount = paymentAmount
            )
        )
    }

    /** Завершить аренду: велосипед освобождается, аренда помечается неактивной. */
    suspend fun completeRental(rentalId: Long) {
        val rental = rentalDao.getById(rentalId) ?: return
        rentalDao.update(rental.copy(active = false, completedDate = System.currentTimeMillis()))
        val bike = bikeDao.getById(rental.bikeId)
        if (bike != null) {
            bikeDao.update(bike.copy(status = BikeStatus.FREE))
        }
    }

    suspend fun markDepositReturned(rentalId: Long) {
        val rental = rentalDao.getById(rentalId) ?: return
        rentalDao.update(
            rental.copy(depositReturned = true, depositReturnDate = System.currentTimeMillis())
        )
    }

    fun observeExtensionsForRental(rentalId: Long): Flow<List<RentalExtensionEntity>> =
        extensionDao.observeForRental(rentalId)

    suspend fun addExtension(extension: RentalExtensionEntity) = extensionDao.insert(extension)

    // ---------- Photos ----------
    fun observePhotosForRental(rentalId: Long): Flow<List<RentalPhotoEntity>> =
        photoDao.observeForRental(rentalId)

    suspend fun addPhoto(photo: RentalPhotoEntity): Long = photoDao.insert(photo)
    suspend fun deletePhoto(photo: RentalPhotoEntity) = photoDao.delete(photo)

    // ---------- Bike photos ----------
    fun observePhotosForBike(bikeId: Long): Flow<List<BikePhotoEntity>> = bikePhotoDao.observeForBike(bikeId)
    suspend fun addBikePhoto(photo: BikePhotoEntity): Long = bikePhotoDao.insert(photo)
    suspend fun deleteBikePhoto(photo: BikePhotoEntity) = bikePhotoDao.delete(photo)

    // ---------- Settings ----------
    fun observeSettings(): Flow<AppSettingsEntity?> = settingsDao.observeSettings()
    suspend fun saveSettings(settings: AppSettingsEntity) = settingsDao.upsert(settings)

    // ---------- Business summary ----------
    data class BusinessSummary(
        val totalBikes: Int,
        val rentedCount: Int,
        val freeCount: Int,
        val repairCount: Int,
        val totalPurchaseCost: Double,
        val totalRepairCost: Double,
        val totalReceived: Double,
        val totalUntilPayback: Double,
        val totalProfit: Double
    )

    fun observeBusinessSummary(): Flow<BusinessSummary> = combine(
        bikeDao.observeAll(),
        repairDao.observeTotalCost(),
        rentalDao.observeTotalReceived()
    ) { bikes, totalRepairCostN, totalReceivedN ->
        val totalRepairCost = totalRepairCostN ?: 0.0
        val totalReceived = totalReceivedN ?: 0.0
        val totalPurchase = bikes.sumOf { it.purchasePrice }

        var untilPayback = 0.0
        var profit = 0.0
        val net = totalReceived - (totalPurchase + totalRepairCost)
        if (net >= 0) profit = net else untilPayback = -net

        BusinessSummary(
            totalBikes = bikes.size,
            rentedCount = bikes.count { it.status == BikeStatus.RENTED },
            freeCount = bikes.count { it.status == BikeStatus.FREE },
            repairCount = bikes.count { it.status == BikeStatus.REPAIR },
            totalPurchaseCost = totalPurchase,
            totalRepairCost = totalRepairCost,
            totalReceived = totalReceived,
            totalUntilPayback = untilPayback,
            totalProfit = profit
        )
    }
}
