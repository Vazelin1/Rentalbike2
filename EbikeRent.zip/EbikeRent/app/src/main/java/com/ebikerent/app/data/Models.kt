package com.ebikerent.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class BikeStatus {
    FREE,       // Свободен
    RENTED,     // В аренде
    REPAIR,     // На ремонте
    UNUSED      // Не используется
}

@Entity(tableName = "bikes")
data class BikeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,                // порядковый номер / бирка велосипеда
    val purchasePrice: Double = 0.0,   // стоимость покупки
    val mileageKm: Double = 0.0,       // текущий пробег
    val status: BikeStatus = BikeStatus.FREE,
    val notes: String = ""
)

@Entity(tableName = "renters")
data class RenterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phone: String = "",
    val comment: String = "",
    val problematic: Boolean = false
)

@Entity(tableName = "repairs")
data class RepairEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bikeId: Long,
    val date: Long,          // epoch millis
    val cost: Double,
    val description: String = ""
)

@Entity(tableName = "rentals")
data class RentalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bikeId: Long,
    val renterId: Long,
    val startDate: Long,          // epoch millis
    val endDate: Long,            // epoch millis
    val price: Double,            // текущая стоимость аренды (суммарная)
    val amountPaid: Double = 0.0, // полученная сумма
    val depositAmount: Double = 0.0,
    val depositReceived: Boolean = false,
    val depositReturned: Boolean = false,
    val depositReturnDate: Long? = null,
    val comment: String = "",
    val active: Boolean = true,   // false когда аренда завершена
    val completedDate: Long? = null
)

@Entity(tableName = "rental_extensions")
data class RentalExtensionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rentalId: Long,
    val date: Long,             // дата продления (когда оформлено)
    val newEndDate: Long,
    val paymentAmount: Double
)

enum class PhotoStage { BEFORE, AFTER }

@Entity(tableName = "rental_photos")
data class RentalPhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rentalId: Long,
    val uri: String,
    val stage: PhotoStage
)

@Entity(tableName = "bike_photos")
data class BikePhotoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bikeId: Long,
    val uri: String
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 0,
    val warningDaysBeforeEnd: Int = 2,
    val darkTheme: Boolean? = null // null = следовать системной теме
)
