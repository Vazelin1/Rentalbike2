package com.ebikerent.app.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.data.AppSettingsEntity
import com.ebikerent.app.util.BackupUtil
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(repository: AppRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val settings by repository.observeSettings().collectAsState(initial = null)

    var warningDaysText by remember(settings) {
        mutableStateOf((settings?.warningDaysBeforeEnd ?: 2).toString())
    }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            BackupUtil.backupTo(context, uri)
            Toast.makeText(context, "Резервная копия сохранена", Toast.LENGTH_SHORT).show()
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            BackupUtil.restoreFrom(context, uri)
            Toast.makeText(context, "Данные восстановлены. Перезапустите приложение.", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Уведомления", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = warningDaysText,
                onValueChange = { warningDaysText = it },
                label = { Text("Дней до окончания аренды для предупреждения") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    scope.launch {
                        repository.saveSettings(
                            AppSettingsEntity(
                                warningDaysBeforeEnd = warningDaysText.toIntOrNull() ?: 2,
                                darkTheme = settings?.darkTheme
                            )
                        )
                    }
                }
            ) { Text("Сохранить") }

            Text("Тема оформления", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            ThemeOption("Системная", settings?.darkTheme == null) {
                scope.launch { repository.saveSettings((settings ?: AppSettingsEntity()).copy(darkTheme = null)) }
            }
            ThemeOption("Светлая", settings?.darkTheme == false) {
                scope.launch { repository.saveSettings((settings ?: AppSettingsEntity()).copy(darkTheme = false)) }
            }
            ThemeOption("Тёмная", settings?.darkTheme == true) {
                scope.launch { repository.saveSettings((settings ?: AppSettingsEntity()).copy(darkTheme = true)) }
            }

            Text("Резервное копирование", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { backupLauncher.launch("ebikerent_backup.db") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Создать резервную копию") }
                    OutlinedButton(
                        onClick = { restoreLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Восстановить из копии") }
                }
            }
        }
    }
}

@Composable
private fun ThemeOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}
