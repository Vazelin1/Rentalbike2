package com.ebikerent.app.ui.rental

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.data.BikeStatus
import com.ebikerent.app.data.PhotoStage
import com.ebikerent.app.data.RentalEntity
import com.ebikerent.app.data.RentalPhotoEntity
import com.ebikerent.app.data.RenterEntity
import com.ebikerent.app.ui.theme.StatusColors
import com.ebikerent.app.util.CurrencyUtils
import com.ebikerent.app.util.DateUtils
import kotlinx.coroutines.launch

// ============================= НОВАЯ АРЕНДА =============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewRentalScreen(
    repository: AppRepository,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val freeBikes by repository.observeFreeBikes().collectAsState(initial = emptyList())
    val renters by repository.observeRenters().collectAsState(initial = emptyList())

    var bikeExpanded by remember { mutableStateOf(false) }
    var selectedBikeId by remember { mutableStateOf<Long?>(null) }

    var renterMode by remember { mutableStateOf(true) } // true = existing, false = new
    var renterExpanded by remember { mutableStateOf(false) }
    var selectedRenterId by remember { mutableStateOf<Long?>(null) }

    var newFullName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newComment by remember { mutableStateOf("") }
    var newProblematic by remember { mutableStateOf(false) }

    var startDate by remember { mutableStateOf(DateUtils.startOfDay()) }
    var endDate by remember { mutableStateOf(DateUtils.addDays(DateUtils.startOfDay(), 1)) }
    var price by remember { mutableStateOf("") }
    var amountPaid by remember { mutableStateOf("") }
    var depositAmount by remember { mutableStateOf("") }
    var depositReceived by remember { mutableStateOf(false) }
    var comment by remember { mutableStateOf("") }

    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }

    val canSave = selectedBikeId != null &&
        (if (renterMode) selectedRenterId != null else newFullName.isNotBlank()) &&
        price.toDoubleOrNull() != null

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Новая аренда") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Велосипед", fontWeight = FontWeight.Bold)
            ExposedDropdownMenuBox(expanded = bikeExpanded, onExpandedChange = { bikeExpanded = it }) {
                OutlinedTextField(
                    value = freeBikes.find { it.id == selectedBikeId }?.number ?: "Выберите свободный велосипед",
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bikeExpanded) }
                )
                ExposedDropdownMenu(expanded = bikeExpanded, onDismissRequest = { bikeExpanded = false }) {
                    if (freeBikes.isEmpty()) {
                        DropdownMenuItem(text = { Text("Нет свободных велосипедов") }, onClick = {})
                    }
                    freeBikes.forEach { bike ->
                        DropdownMenuItem(
                            text = { Text("№ ${bike.number}") },
                            onClick = { selectedBikeId = bike.id; bikeExpanded = false }
                        )
                    }
                }
            }

            Text("Арендатор", fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Существующий")
                Checkbox(checked = renterMode, onCheckedChange = { renterMode = true })
                Spacer(Modifier.width(12.dp))
                Text("Новый")
                Checkbox(checked = !renterMode, onCheckedChange = { renterMode = false })
            }

            if (renterMode) {
                ExposedDropdownMenuBox(expanded = renterExpanded, onExpandedChange = { renterExpanded = it }) {
                    OutlinedTextField(
                        value = renters.find { it.id == selectedRenterId }?.fullName ?: "Выберите арендатора",
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().menuAnchor(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = renterExpanded) }
                    )
                    ExposedDropdownMenu(expanded = renterExpanded, onDismissRequest = { renterExpanded = false }) {
                        renters.forEach { renter ->
                            DropdownMenuItem(
                                text = { Text(renter.fullName) },
                                onClick = { selectedRenterId = renter.id; renterExpanded = false }
                            )
                        }
                    }
                }
            } else {
                OutlinedTextField(value = newFullName, onValueChange = { newFullName = it }, label = { Text("ФИО") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = newPhone, onValueChange = { newPhone = it }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = newComment, onValueChange = { newComment = it }, label = { Text("Комментарий") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = newProblematic, onCheckedChange = { newProblematic = it })
                    Text("Проблемный клиент")
                }
            }

            Text("Информация по аренде", fontWeight = FontWeight.Bold)

            OutlinedButton(onClick = { showStartPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Дата начала: ${DateUtils.formatDate(startDate)}")
            }
            OutlinedButton(onClick = { showEndPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Дата окончания: ${DateUtils.formatDate(endDate)}")
            }

            OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Стоимость аренды, ₽") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = amountPaid, onValueChange = { amountPaid = it }, label = { Text("Получено сейчас, ₽") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = depositAmount, onValueChange = { depositAmount = it }, label = { Text("Сумма залога, ₽") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = depositReceived, onCheckedChange = { depositReceived = it })
                Text("Залог получен")
            }
            OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Комментарий") }, modifier = Modifier.fillMaxWidth())

            Button(
                onClick = {
                    scope.launch {
                        val renterId = if (renterMode) {
                            selectedRenterId!!
                        } else {
                            repository.addRenter(
                                RenterEntity(
                                    fullName = newFullName,
                                    phone = newPhone,
                                    comment = newComment,
                                    problematic = newProblematic
                                )
                            )
                        }
                        repository.createRental(
                            RentalEntity(
                                bikeId = selectedBikeId!!,
                                renterId = renterId,
                                startDate = startDate,
                                endDate = endDate,
                                price = price.toDoubleOrNull() ?: 0.0,
                                amountPaid = amountPaid.toDoubleOrNull() ?: 0.0,
                                depositAmount = depositAmount.toDoubleOrNull() ?: 0.0,
                                depositReceived = depositReceived,
                                comment = comment
                            )
                        )
                        onDone()
                    }
                },
                enabled = canSave,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Оформить аренду")
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showStartPicker) {
        DatePickerModal(
            initial = startDate,
            onConfirm = { startDate = it; showStartPicker = false },
            onDismiss = { showStartPicker = false }
        )
    }
    if (showEndPicker) {
        DatePickerModal(
            initial = endDate,
            onConfirm = { endDate = it; showEndPicker = false },
            onDismiss = { showEndPicker = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DatePickerModal(initial: Long, onConfirm: (Long) -> Unit, onDismiss: () -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { state.selectedDateMillis?.let(onConfirm) ?: onDismiss() }) { Text("Готово") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    ) {
        DatePicker(state = state)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExposedDropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    content: @Composable () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismissRequest, content = content)
}

// ============================= КАРТОЧКА АРЕНДЫ =============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RentalDetailScreen(
    repository: AppRepository,
    rentalId: Long,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val rental by repository.observeRental(rentalId).collectAsState(initial = null)
    val extensions by repository.observeExtensionsForRental(rentalId).collectAsState(initial = emptyList())
    val photos by repository.observePhotosForRental(rentalId).collectAsState(initial = emptyList())

    val r = rental ?: run {
        Scaffold(topBar = { TopAppBar(title = { Text("Аренда") }) }) { p ->
            Column(Modifier.padding(p).padding(16.dp)) { Text("Загрузка...") }
        }
        return
    }

    var renterName by remember { mutableStateOf("") }
    var bikeNumber by remember { mutableStateOf("") }
    LaunchedEffectSafe(repository, r.renterId, r.bikeId) { rn, bn -> renterName = rn; bikeNumber = bn }

    var editEndDate by remember(r.id) { mutableStateOf(r.endDate) }
    var editPrice by remember(r.id) { mutableStateOf(r.price.toString()) }
    var editComment by remember(r.id) { mutableStateOf(r.comment) }
    var editDeposit by remember(r.id) { mutableStateOf(r.depositAmount.toString()) }

    var showEndPicker by remember { mutableStateOf(false) }
    var showExtendDialog by remember { mutableStateOf(false) }
    var showCompleteConfirm by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }

    val photoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            scope.launch {
                uris.forEach { uri ->
                    repository.addPhoto(RentalPhotoEntity(rentalId = rentalId, uri = uri.toString(), stage = PhotoStage.AFTER))
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Аренда: велосипед № $bikeNumber") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Детали") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Продления") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Фото") })
            }

            Column(
                modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        Text(renterName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Начало: ${DateUtils.formatDate(r.startDate)}")

                        OutlinedButton(onClick = { showEndPicker = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Окончание: ${DateUtils.formatDate(editEndDate)}")
                        }

                        OutlinedTextField(
                            value = editPrice, onValueChange = { editPrice = it },
                            label = { Text("Стоимость аренды, ₽") }, modifier = Modifier.fillMaxWidth()
                        )
                        Text("Получено: ${CurrencyUtils.formatRub(r.amountPaid)}")

                        OutlinedTextField(
                            value = editDeposit, onValueChange = { editDeposit = it },
                            label = { Text("Сумма залога, ₽") }, modifier = Modifier.fillMaxWidth()
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (r.depositReturned) "Залог возвращён" else "Залог не возвращён")
                            Spacer(Modifier.width(8.dp))
                            if (!r.depositReturned) {
                                TextButton(onClick = { scope.launch { repository.markDepositReturned(rentalId) } }) {
                                    Text("Отметить возврат")
                                }
                            }
                        }

                        OutlinedTextField(
                            value = editComment, onValueChange = { editComment = it },
                            label = { Text("Комментарий") }, modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                scope.launch {
                                    repository.updateRental(
                                        r.copy(
                                            endDate = editEndDate,
                                            price = editPrice.toDoubleOrNull() ?: r.price,
                                            depositAmount = editDeposit.toDoubleOrNull() ?: r.depositAmount,
                                            comment = editComment
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Сохранить изменения") }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { showExtendDialog = true }, modifier = Modifier.weight(1f)) {
                                Text("Продлить аренду")
                            }
                            OutlinedButton(onClick = { showCompleteConfirm = true }, modifier = Modifier.weight(1f)) {
                                Text("Завершить")
                            }
                        }
                    }
                    1 -> {
                        if (extensions.isEmpty()) {
                            Text("Продлений пока не было")
                        } else {
                            extensions.forEach { ext ->
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text("До ${DateUtils.formatDate(ext.newEndDate)}", fontWeight = FontWeight.Bold)
                                        Text("Оплата: ${CurrencyUtils.formatRub(ext.paymentAmount)}")
                                        Text("Дата продления: ${DateUtils.formatDate(ext.date)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        Button(onClick = {
                            photoLauncher.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    mediaType = ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        }) {
                            Icon(Icons.Filled.AddAPhoto, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Добавить фото возврата")
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(photos, key = { it.id }) { photo ->
                                AsyncImage(
                                    model = Uri.parse(photo.uri),
                                    contentDescription = null,
                                    modifier = Modifier.size(96.dp).background(Color.LightGray, RoundedCornerShape(8.dp))
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEndPicker) {
        DatePickerModal(
            initial = editEndDate,
            onConfirm = { editEndDate = it; showEndPicker = false },
            onDismiss = { showEndPicker = false }
        )
    }

    if (showExtendDialog) {
        ExtendRentalDialog(
            currentEndDate = r.endDate,
            onConfirm = { newEndDate, amount ->
                scope.launch { repository.extendRental(rentalId, newEndDate, amount) }
                showExtendDialog = false
            },
            onDismiss = { showExtendDialog = false }
        )
    }

    if (showCompleteConfirm) {
        AlertDialog(
            onDismissRequest = { showCompleteConfirm = false },
            title = { Text("Завершить аренду?") },
            text = { Text("Велосипед станет свободным, аренда переместится в историю.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repository.completeRental(rentalId) }
                    showCompleteConfirm = false
                    onBack()
                }) { Text("Завершить") }
            },
            dismissButton = { TextButton(onClick = { showCompleteConfirm = false }) { Text("Отмена") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExtendRentalDialog(
    currentEndDate: Long,
    onConfirm: (Long, Double) -> Unit,
    onDismiss: () -> Unit
) {
    var newEndDate by remember { mutableStateOf(DateUtils.addDays(currentEndDate, 1)) }
    var payment by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Продление аренды") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Новая дата: ${DateUtils.formatDate(newEndDate)}")
                }
                OutlinedTextField(
                    value = payment, onValueChange = { payment = it },
                    label = { Text("Сумма оплаты, ₽") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(newEndDate, payment.toDoubleOrNull() ?: 0.0)
            }) { Text("Продлить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )

    if (showPicker) {
        DatePickerModal(
            initial = newEndDate,
            onConfirm = { newEndDate = it; showPicker = false },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
private fun LaunchedEffectSafe(
    repository: AppRepository,
    renterId: Long,
    bikeId: Long,
    onResult: (String, String) -> Unit
) {
    val renter by repository.observeRenter(renterId).collectAsState(initial = null)
    val bike by repository.observeBike(bikeId).collectAsState(initial = null)
    androidx.compose.runtime.LaunchedEffect(renter, bike) {
        onResult(renter?.fullName ?: "", bike?.number ?: "")
    }
}
