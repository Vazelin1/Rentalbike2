package com.ebikerent.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.ui.bikes.BikeDetailScreen
import com.ebikerent.app.ui.bikes.BikesScreen
import com.ebikerent.app.ui.home.HomeScreen
import com.ebikerent.app.ui.rental.NewRentalScreen
import com.ebikerent.app.ui.rental.RentalDetailScreen
import com.ebikerent.app.ui.renters.RenterDetailScreen
import com.ebikerent.app.ui.renters.RentersScreen
import com.ebikerent.app.ui.settings.SettingsScreen
import com.ebikerent.app.ui.summary.SummaryScreen

sealed class Dest(val route: String, val label: String) {
    data object Home : Dest("home", "Главная")
    data object Bikes : Dest("bikes", "Велосипеды")
    data object Renters : Dest("renters", "Арендаторы")
    data object Summary : Dest("summary", "Итоги")
}

private val bottomItems = listOf(Dest.Home, Dest.Bikes, Dest.Renters, Dest.Summary)

@Composable
fun AppNavHost(repository: AppRepository) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { AppBottomBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(innerPadding)
        ) {
            composable(Dest.Home.route) {
                HomeScreen(
                    repository = repository,
                    onOpenRental = { id -> navController.navigate("rental_detail/$id") },
                    onNewRental = { navController.navigate("new_rental") },
                    onOpenSettings = { navController.navigate("settings") }
                )
            }
            composable(Dest.Bikes.route) {
                BikesScreen(
                    repository = repository,
                    onOpenBike = { id -> navController.navigate("bike_detail/$id") }
                )
            }
            composable(Dest.Renters.route) {
                RentersScreen(
                    repository = repository,
                    onOpenRenter = { id -> navController.navigate("renter_detail/$id") }
                )
            }
            composable(Dest.Summary.route) {
                SummaryScreen(repository = repository)
            }
            composable(
                route = "bike_detail/{bikeId}",
                arguments = listOf(navArgument("bikeId") { type = NavType.LongType })
            ) { backStackEntry ->
                val bikeId = backStackEntry.arguments?.getLong("bikeId") ?: 0L
                BikeDetailScreen(
                    repository = repository,
                    bikeId = bikeId,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = "renter_detail/{renterId}",
                arguments = listOf(navArgument("renterId") { type = NavType.LongType })
            ) { backStackEntry ->
                val renterId = backStackEntry.arguments?.getLong("renterId") ?: 0L
                RenterDetailScreen(
                    repository = repository,
                    renterId = renterId,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = "rental_detail/{rentalId}",
                arguments = listOf(navArgument("rentalId") { type = NavType.LongType })
            ) { backStackEntry ->
                val rentalId = backStackEntry.arguments?.getLong("rentalId") ?: 0L
                RentalDetailScreen(
                    repository = repository,
                    rentalId = rentalId,
                    onBack = { navController.popBackStack() }
                )
            }
            composable("new_rental") {
                NewRentalScreen(
                    repository = repository,
                    onDone = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
            composable("settings") {
                SettingsScreen(repository = repository, onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun AppBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination

    NavigationBar {
        bottomItems.forEach { dest ->
            val selected = currentRoute?.hierarchy?.any { it.route == dest.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(dest.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    Icon(
                        imageVector = when (dest) {
                            Dest.Home -> Icons.Filled.Home
                            Dest.Bikes -> Icons.Filled.DirectionsBike
                            Dest.Renters -> Icons.Filled.People
                            Dest.Summary -> Icons.Filled.Assessment
                        },
                        contentDescription = dest.label
                    )
                },
                label = { Text(dest.label) }
            )
        }
    }
}
