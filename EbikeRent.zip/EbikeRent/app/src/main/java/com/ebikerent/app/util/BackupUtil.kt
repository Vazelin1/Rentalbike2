package com.ebikerent.app.util

import android.content.Context
import android.net.Uri
import com.ebikerent.app.data.AppDatabase
import java.io.File

/**
 * Простое резервное копирование: копирует файл базы данных Room в выбранный
 * пользователем URI (через Storage Access Framework) и обратно при восстановлении.
 * Перед копированием/восстановлением база данных должна быть закрыта.
 */
object BackupUtil {

    fun dbFile(context: Context): File = context.getDatabasePath(AppDatabase.DB_NAME)

    fun backupTo(context: Context, targetUri: Uri) {
        val source = dbFile(context)
        if (!source.exists()) return
        context.contentResolver.openOutputStream(targetUri)?.use { out ->
            source.inputStream().use { input -> input.copyTo(out) }
        }
    }

    fun restoreFrom(context: Context, sourceUri: Uri) {
        val target = dbFile(context)
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            target.outputStream().use { out -> input.copyTo(out) }
        }
        // Также удаляем -wal/-shm файлы, чтобы не было рассинхрона со старыми данными.
        File(target.path + "-wal").delete()
        File(target.path + "-shm").delete()
    }
}
