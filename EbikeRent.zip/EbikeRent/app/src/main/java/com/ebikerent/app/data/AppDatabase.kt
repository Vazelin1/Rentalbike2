package com.ebikerent.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        BikeEntity::class,
        RenterEntity::class,
        RepairEntity::class,
        RentalEntity::class,
        RentalExtensionEntity::class,
        RentalPhotoEntity::class,
        BikePhotoEntity::class,
        AppSettingsEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bikeDao(): BikeDao
    abstract fun renterDao(): RenterDao
    abstract fun repairDao(): RepairDao
    abstract fun rentalDao(): RentalDao
    abstract fun rentalExtensionDao(): RentalExtensionDao
    abstract fun rentalPhotoDao(): RentalPhotoDao
    abstract fun bikePhotoDao(): BikePhotoDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        const val DB_NAME = "ebikerent.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    // Простая стратегия для локального приложения на раннем этапе:
                    // при изменении схемы база пересоздаётся, а не мигрируется вручную.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
