package com.ebikerent.app.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ebikerent.app.data.AppDatabase
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.util.DateUtils
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/**
 * Ежедневно проверяет активные аренды и отправляет уведомления:
 * за N дней (настраивается пользователем) до окончания, в день окончания,
 * и ежедневно по просроченным арендам.
 */
class RentalCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repository = AppRepository(AppDatabase.getInstance(applicationContext))
        val settings = repository.observeSettings().first()
        val warningDays = settings?.warningDaysBeforeEnd ?: 2

        val activeRentals = repository.observeActiveRentals().first()
        val renters = repository.observeRenters().first().associateBy { it.id }
        val bikes = repository.observeBikes().first().associateBy { it.id }

        ensureChannel()

        for (rental in activeRentals) {
            val daysLeft = DateUtils.daysUntil(rental.endDate)
            val renterName = renters[rental.renterId]?.fullName ?: "Арендатор"
            val bikeNumber = bikes[rental.bikeId]?.number ?: "?"

            when {
                daysLeft < 0 -> notify(
                    id = rental.id.toInt(),
                    title = "Просрочена аренда: велосипед $bikeNumber",
                    text = "$renterName — просрочка ${-daysLeft} дн."
                )
                daysLeft == 0 -> notify(
                    id = rental.id.toInt(),
                    title = "Сегодня заканчивается аренда: велосипед $bikeNumber",
                    text = renterName
                )
                daysLeft == warningDays -> notify(
                    id = rental.id.toInt(),
                    title = "Скоро заканчивается аренда: велосипед $bikeNumber",
                    text = "$renterName — осталось $daysLeft дн."
                )
            }
        }
        return Result.success()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Напоминания об аренде",
                NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(channel)
        }
    }

    private fun notify(id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ActivityCompat.checkSelfPermission(
                applicationContext, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        androidx.core.app.NotificationManagerCompat.from(applicationContext).notify(id, notification)
    }

    companion object {
        private const val CHANNEL_ID = "rental_reminders"
        private const val WORK_NAME = "rental_check_daily"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<RentalCheckWorker>(24, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
