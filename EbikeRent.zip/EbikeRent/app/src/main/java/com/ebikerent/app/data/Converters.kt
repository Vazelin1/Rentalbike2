package com.ebikerent.app.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromBikeStatus(status: BikeStatus): String = status.name

    @TypeConverter
    fun toBikeStatus(value: String): BikeStatus = BikeStatus.valueOf(value)

    @TypeConverter
    fun fromPhotoStage(stage: PhotoStage): String = stage.name

    @TypeConverter
    fun toPhotoStage(value: String): PhotoStage = PhotoStage.valueOf(value)
}
