package com.ebikerent.app.ui.summary

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.ui.theme.StatusColors
import com.ebikerent.app.util.CurrencyUtils

@Composable
fun SummaryScreen(repository: AppRepository) {
    val summary by repository.observeBusinessSummary().collectAsState(
        initial = AppRepository.BusinessSummary(0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0)
    )

    Scaffold(topBar = { TopAppBar(title = { Text("Итоги") }) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SummaryRow("🚲 Всего велосипедов", summary.totalBikes.toString())
            SummaryRow("🔵 Сейчас в аренде", summary.rentedCount.toString(), StatusColors.Rented)
            SummaryRow("🟢 Свободных", summary.freeCount.toString(), StatusColors.Free)
            SummaryRow("🟠 На ремонте", summary.repairCount.toString(), StatusColors.Repair)
            SummaryRow("💰 Потрачено на покупку", CurrencyUtils.formatRub(summary.totalPurchaseCost))
            SummaryRow("🔧 Потрачено на ремонты", CurrencyUtils.formatRub(summary.totalRepairCost))
            SummaryRow("💵 Получено от аренды", CurrencyUtils.formatRub(summary.totalReceived))
            SummaryRow("💸 До окупаемости (неокупившиеся)", CurrencyUtils.formatRub(summary.totalUntilPayback), StatusColors.Repair)
            SummaryRow("📈 Общая прибыль", CurrencyUtils.formatRub(summary.totalProfit), StatusColors.Free)
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color? = null) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label)
            Text(
                value,
                fontWeight = FontWeight.Bold,
                color = valueColor ?: MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
