package com.ebikerent.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BikeDao {
    @Query("SELECT * FROM bikes ORDER BY number ASC")
    fun observeAll(): Flow<List<BikeEntity>>

    @Query("SELECT * FROM bikes WHERE status = :status ORDER BY number ASC")
    fun observeByStatus(status: BikeStatus): Flow<List<BikeEntity>>

    @Query("SELECT * FROM bikes WHERE id = :id")
    fun observeById(id: Long): Flow<BikeEntity?>

    @Query("SELECT * FROM bikes WHERE id = :id")
    suspend fun getById(id: Long): BikeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bike: BikeEntity): Long

    @Update
    suspend fun update(bike: BikeEntity)

    @Delete
    suspend fun delete(bike: BikeEntity)

    @Query("SELECT COUNT(*) FROM bikes")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM bikes WHERE status = :status")
    fun observeCountByStatus(status: BikeStatus): Flow<Int>

    @Query("SELECT SUM(purchasePrice) FROM bikes")
    fun observeTotalPurchaseCost(): Flow<Double?>
}

@Dao
interface RenterDao {
    @Query("SELECT * FROM renters ORDER BY fullName ASC")
    fun observeAll(): Flow<List<RenterEntity>>

    @Query("SELECT * FROM renters WHERE fullName LIKE '%' || :query || '%' ORDER BY fullName ASC")
    fun search(query: String): Flow<List<RenterEntity>>

    @Query("SELECT * FROM renters WHERE id = :id")
    fun observeById(id: Long): Flow<RenterEntity?>

    @Query("SELECT * FROM renters WHERE id = :id")
    suspend fun getById(id: Long): RenterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(renter: RenterEntity): Long

    @Update
    suspend fun update(renter: RenterEntity)

    @Delete
    suspend fun delete(renter: RenterEntity)
}

@Dao
interface RepairDao {
    @Query("SELECT * FROM repairs WHERE bikeId = :bikeId ORDER BY date DESC")
    fun observeForBike(bikeId: Long): Flow<List<RepairEntity>>

    @Query("SELECT SUM(cost) FROM repairs WHERE bikeId = :bikeId")
    fun observeTotalCostForBike(bikeId: Long): Flow<Double?>

    @Query("SELECT SUM(cost) FROM repairs")
    fun observeTotalCost(): Flow<Double?>

    @Insert
    suspend fun insert(repair: RepairEntity): Long

    @Update
    suspend fun update(repair: RepairEntity)

    @Delete
    suspend fun delete(repair: RepairEntity)
}

@Dao
interface RentalDao {
    @Query("SELECT * FROM rentals WHERE active = 1 ORDER BY endDate ASC")
    fun observeActive(): Flow<List<RentalEntity>>

    @Query("SELECT * FROM rentals WHERE bikeId = :bikeId ORDER BY startDate DESC")
    fun observeForBike(bikeId: Long): Flow<List<RentalEntity>>

    @Query("SELECT * FROM rentals WHERE renterId = :renterId ORDER BY startDate DESC")
    fun observeForRenter(renterId: Long): Flow<List<RentalEntity>>

    @Query("SELECT * FROM rentals WHERE id = :id")
    fun observeById(id: Long): Flow<RentalEntity?>

    @Query("SELECT * FROM rentals WHERE id = :id")
    suspend fun getById(id: Long): RentalEntity?

    @Query("SELECT * FROM rentals WHERE bikeId = :bikeId AND active = 1 LIMIT 1")
    suspend fun getActiveForBike(bikeId: Long): RentalEntity?

    @Insert
    suspend fun insert(rental: RentalEntity): Long

    @Update
    suspend fun update(rental: RentalEntity)

    @Delete
    suspend fun delete(rental: RentalEntity)

    @Query("SELECT SUM(amountPaid) FROM rentals")
    fun observeTotalReceived(): Flow<Double?>

    @Query("SELECT SUM(amountPaid) FROM rentals WHERE bikeId = :bikeId")
    fun observeTotalReceivedForBike(bikeId: Long): Flow<Double?>

    @Query("SELECT COUNT(*) FROM rentals WHERE bikeId = :bikeId")
    fun observeCountForBike(bikeId: Long): Flow<Int>

    @Query("SELECT SUM(amountPaid) FROM rentals WHERE renterId = :renterId")
    fun observeTotalPaidByRenter(renterId: Long): Flow<Double?>

    @Query("SELECT COUNT(*) FROM rentals WHERE renterId = :renterId")
    fun observeCountForRenter(renterId: Long): Flow<Int>

    @Query("SELECT MAX(startDate) FROM rentals WHERE renterId = :renterId")
    fun observeLastRentalDateForRenter(renterId: Long): Flow<Long?>

    @Query("SELECT MAX(startDate) FROM rentals WHERE bikeId = :bikeId")
    fun observeLastRentalDateForBike(bikeId: Long): Flow<Long?>
}

@Dao
interface RentalExtensionDao {
    @Query("SELECT * FROM rental_extensions WHERE rentalId = :rentalId ORDER BY date ASC")
    fun observeForRental(rentalId: Long): Flow<List<RentalExtensionEntity>>

    @Insert
    suspend fun insert(extension: RentalExtensionEntity): Long
}

@Dao
interface RentalPhotoDao {
    @Query("SELECT * FROM rental_photos WHERE rentalId = :rentalId ORDER BY id ASC")
    fun observeForRental(rentalId: Long): Flow<List<RentalPhotoEntity>>

    @Insert
    suspend fun insert(photo: RentalPhotoEntity): Long

    @Delete
    suspend fun delete(photo: RentalPhotoEntity)
}

@Dao
interface BikePhotoDao {
    @Query("SELECT * FROM bike_photos WHERE bikeId = :bikeId ORDER BY id ASC")
    fun observeForBike(bikeId: Long): Flow<List<BikePhotoEntity>>

    @Insert
    suspend fun insert(photo: BikePhotoEntity): Long

    @Delete
    suspend fun delete(photo: BikePhotoEntity)
}

@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 0")
    fun observeSettings(): Flow<AppSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(settings: AppSettingsEntity)
}
