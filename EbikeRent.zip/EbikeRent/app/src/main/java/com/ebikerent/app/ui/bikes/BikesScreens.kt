package com.ebikerent.app.ui.bikes

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.data.BikeEntity
import com.ebikerent.app.data.BikePhotoEntity
import com.ebikerent.app.data.BikeStatus
import com.ebikerent.app.data.RepairEntity
import com.ebikerent.app.ui.theme.StatusColors
import com.ebikerent.app.util.CurrencyUtils
import com.ebikerent.app.util.DateUtils
import kotlinx.coroutines.launch

private fun statusColor(status: BikeStatus) = when (status) {
    BikeStatus.FREE -> StatusColors.Free
    BikeStatus.RENTED -> StatusColors.Rented
    BikeStatus.REPAIR -> StatusColors.Repair
    BikeStatus.UNUSED -> StatusColors.Unused
}

private fun statusLabel(status: BikeStatus) = when (status) {
    BikeStatus.FREE -> "Свободен"
    BikeStatus.RENTED -> "В аренде"
    BikeStatus.REPAIR -> "На ремонте"
    BikeStatus.UNUSED -> "Не используется"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BikesScreen(repository: AppRepository, onOpenBike: (Long) -> Unit) {
    val scope = rememberCoroutineScope()
    val bikes by repository.observeBikes().collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Велосипеды") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить велосипед")
            }
        }
    ) { padding ->
        if (bikes.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Велосипедов пока нет. Нажмите +, чтобы добавить.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(bikes, key = { it.id }) { bike ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenBike(bike.id) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(14.dp).background(statusColor(bike.status), CircleShape)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("№ ${bike.number}", fontWeight = FontWeight.Bold)
                                Text(statusLabel(bike.status), color = statusColor(bike.status))
                            }
                            Text(CurrencyUtils.formatRub(bike.purchasePrice))
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddBikeDialog(
            onConfirm = { number, price ->
                scope.launch {
                    repository.addBike(BikeEntity(number = number, purchasePrice = price))
                }
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun AddBikeDialog(onConfirm: (String, Double) -> Unit, onDismiss: () -> Unit) {
    var number by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый велосипед") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = number, onValueChange = { number = it }, label = { Text("Номер") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Стоимость покупки, ₽") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(number, price.toDoubleOrNull() ?: 0.0) },
                enabled = number.isNotBlank()
            ) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BikeDetailScreen(repository: AppRepository, bikeId: Long, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val bike by repository.observeBike(bikeId).collectAsState(initial = null)
    val repairs by repository.observeRepairsForBike(bikeId).collectAsState(initial = emptyList())
    val repairCost by repository.observeRepairCostForBike(bikeId).collectAsState(initial = 0.0)
    val received by repository.observeReceivedForBike(bikeId).collectAsState(initial = 0.0)
    val rentalCount by repository.observeRentalCountForBike(bikeId).collectAsState(initial = 0)
    val lastRentalDate by repository.observeLastRentalDateForBike(bikeId).collectAsState(initial = null)
    val rentals by repository.observeRentalsForBike(bikeId).collectAsState(initial = emptyList())
    val renters by repository.observeRenters().collectAsState(initial = emptyList())
    val bikePhotos by repository.observePhotosForBike(bikeId).collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) }
    var showRepairDialog by remember { mutableStateOf(false) }
    var showStatusMenu by remember { mutableStateOf(false) }
    var fullscreenPhotoUri by remember { mutableStateOf<String?>(null) }

    val bikePhotoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            scope.launch {
                uris.forEach { uri ->
                    repository.addBikePhoto(BikePhotoEntity(bikeId = bikeId, uri = uri.toString()))
                }
            }
        }
    }

    val b = bike ?: run {
        Scaffold(topBar = { TopAppBar(title = { Text("Велосипед") }) }) { p -> Box(Modifier.padding(p)) }
        return
    }

    val totalRepairCost = repairCost ?: 0.0
    val totalReceived = received ?: 0.0
    val net = totalReceived - (b.purchasePrice + totalRepairCost)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Велосипед № ${b.number}") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = null) } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Инфо") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Ремонты") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("История аренд") })
            }

            Column(
                Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        Text("Фото велосипеда", fontWeight = FontWeight.Bold)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable {
                                            bikePhotoLauncher.launch(
                                                PickVisualMediaRequest(
                                                    mediaType = ActivityResultContracts.PickVisualMedia.ImageOnly
                                                )
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.AddAPhoto, contentDescription = "Добавить фото")
                                }
                            }
                            items(bikePhotos, key = { it.id }) { photo ->
                                AsyncImage(
                                    model = Uri.parse(photo.uri),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { fullscreenPhotoUri = photo.uri }
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Статус: ", fontWeight = FontWeight.Bold)
                            ExposedDropdownMenuBox(expanded = showStatusMenu, onExpandedChange = { showStatusMenu = it }) {
                                OutlinedTextField(
                                    value = statusLabel(b.status),
                                    onValueChange = {},
                                    readOnly = true,
                                    modifier = Modifier.menuAnchor(),
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showStatusMenu) }
                                )
                                DropdownMenu(expanded = showStatusMenu, onDismissRequest = { showStatusMenu = false }) {
                                    BikeStatus.values().forEach { status ->
                                        DropdownMenuItem(
                                            text = { Text(statusLabel(status)) },
                                            onClick = {
                                                scope.launch { repository.updateBike(b.copy(status = status)) }
                                                showStatusMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        InfoRow("Стоимость покупки", CurrencyUtils.formatRub(b.purchasePrice))
                        InfoRow("Пробег", "${b.mileageKm.toInt()} км")
                        InfoRow("Общий доход", CurrencyUtils.formatRub(totalReceived))
                        InfoRow("Расходы на ремонт", CurrencyUtils.formatRub(totalRepairCost))
                        InfoRow("Количество аренд", rentalCount.toString())
                        InfoRow(
                            "Последняя аренда",
                            lastRentalDate?.let { DateUtils.formatDate(it) } ?: "—"
                        )

                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                if (net >= 0) {
                                    Text("Прибыль", color = StatusColors.Free, fontWeight = FontWeight.Bold)
                                    Text(CurrencyUtils.formatRub(net), style = MaterialTheme.typography.headlineSmall)
                                } else {
                                    Text("До окупаемости", color = StatusColors.Repair, fontWeight = FontWeight.Bold)
                                    Text(CurrencyUtils.formatRub(-net), style = MaterialTheme.typography.headlineSmall)
                                }
                            }
                        }
                    }
                    1 -> {
                        Button(onClick = { showRepairDialog = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Добавить ремонт")
                        }
                        if (repairs.isEmpty()) {
                            Text("Ремонтов не было")
                        } else {
                            repairs.forEach { repair ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(CurrencyUtils.formatRub(repair.cost), fontWeight = FontWeight.Bold)
                                        Text(repair.description)
                                        Text(DateUtils.formatDate(repair.date), style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        if (rentals.isEmpty()) {
                            Text("Аренд ещё не было")
                        } else {
                            rentals.forEach { rental ->
                                val renterName = renters.find { it.id == rental.renterId }?.fullName ?: "?"
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(renterName, fontWeight = FontWeight.Bold)
                                        Text("${DateUtils.formatDate(rental.startDate)} — ${DateUtils.formatDate(rental.endDate)}")
                                        Text("Итого: ${CurrencyUtils.formatRub(rental.price)}")
                                        if (!rental.active) Text("Завершена", color = StatusColors.Unused)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showRepairDialog) {
        AddRepairDialog(
            onConfirm = { cost, description ->
                scope.launch {
                    repository.addRepair(
                        RepairEntity(bikeId = bikeId, date = System.currentTimeMillis(), cost = cost, description = description)
                    )
                }
                showRepairDialog = false
            },
            onDismiss = { showRepairDialog = false }
        )
    }

    val photoToShow = fullscreenPhotoUri
    if (photoToShow != null) {
        FullscreenPhotoDialog(
            uri = photoToShow,
            onDismiss = { fullscreenPhotoUri = null }
        )
    }
}

@Composable
private fun FullscreenPhotoDialog(uri: String, onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(androidx.compose.ui.graphics.Color.Black)
                .clickable(onClick = onDismiss)
        ) {
            AsyncImage(
                model = Uri.parse(uri),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
            ) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Закрыть",
                    tint = androidx.compose.ui.graphics.Color.White
                )
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun AddRepairDialog(onConfirm: (Double, String) -> Unit, onDismiss: () -> Unit) {
    var cost by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый ремонт") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = cost, onValueChange = { cost = it }, label = { Text("Стоимость, ₽") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Описание") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(cost.toDoubleOrNull() ?: 0.0, description) }) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
