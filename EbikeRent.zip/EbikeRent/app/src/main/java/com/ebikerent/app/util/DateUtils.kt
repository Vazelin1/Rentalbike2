package com.ebikerent.app.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object DateUtils {
    private val displayFormat = SimpleDateFormat("dd.MM.yyyy", Locale("ru"))

    fun formatDate(millis: Long): String = displayFormat.format(Date(millis))

    fun startOfDay(millis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = millis
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun addDays(millis: Long, days: Int): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = millis
        cal.add(Calendar.DAY_OF_YEAR, days)
        return cal.timeInMillis
    }

    /** Количество полных дней от сейчас до endDate (может быть отрицательным, если просрочено). */
    fun daysUntil(endDateMillis: Long): Int {
        val today = startOfDay()
        val end = startOfDay(endDateMillis)
        val diff = end - today
        return TimeUnit.MILLISECONDS.toDays(diff).toInt()
    }
}

object CurrencyUtils {
    private val format = NumberFormat.getNumberInstance(Locale("ru")).apply {
        maximumFractionDigits = 0
    }

    fun formatRub(amount: Double): String = "${format.format(amount)} ₽"
}
