package com.ebikerent.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.data.BikeStatus
import com.ebikerent.app.data.RentalEntity
import com.ebikerent.app.ui.theme.StatusColors
import com.ebikerent.app.util.CurrencyUtils
import com.ebikerent.app.util.DateUtils

private enum class HomeFilter(val label: String) {
    ALL("Все"),
    RENTED("В аренде"),
    FREE("Свободные"),
    DUE_TODAY("Заканчиваются сегодня"),
    OVERDUE("Просроченные")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: AppRepository,
    onOpenRental: (Long) -> Unit,
    onNewRental: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val bikes by repository.observeBikes().collectAsState(initial = emptyList())
    val renters by repository.observeRenters().collectAsState(initial = emptyList())
    val activeRentals by repository.observeActiveRentals().collectAsState(initial = emptyList())

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(HomeFilter.ALL) }

    val rentersById = renters.associateBy { it.id }
    val bikesById = bikes.associateBy { it.id }

    val totalBikes = bikes.size
    val rentedCount = bikes.count { it.status == BikeStatus.RENTED }
    val freeCount = bikes.count { it.status == BikeStatus.FREE }
    val repairCount = bikes.count { it.status == BikeStatus.REPAIR }
    val dueTodayCount = activeRentals.count { DateUtils.daysUntil(it.endDate) == 0 }
    val overdueCount = activeRentals.count { DateUtils.daysUntil(it.endDate) < 0 }

    val filteredRentals = activeRentals.filter { rental ->
        val renterName = rentersById[rental.renterId]?.fullName.orEmpty()
        val bikeNumber = bikesById[rental.bikeId]?.number.orEmpty()
        val matchesQuery = query.isBlank() ||
            renterName.contains(query, ignoreCase = true) ||
            bikeNumber.contains(query, ignoreCase = true)

        val daysLeft = DateUtils.daysUntil(rental.endDate)
        val matchesFilter = when (filter) {
            HomeFilter.ALL -> true
            HomeFilter.RENTED -> true
            HomeFilter.FREE -> false // свободные велосипеды не имеют активной аренды
            HomeFilter.DUE_TODAY -> daysLeft == 0
            HomeFilter.OVERDUE -> daysLeft < 0
        }
        matchesQuery && matchesFilter
    }.sortedBy { it.endDate }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Главная") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Настройки")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewRental) {
                Icon(Icons.Filled.Add, contentDescription = "Новая аренда")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            StatsBar(
                totalBikes = totalBikes,
                rentedCount = rentedCount,
                freeCount = freeCount,
                repairCount = repairCount,
                dueTodayCount = dueTodayCount,
                overdueCount = overdueCount
            )

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Поиск: номер велосипеда или ФИО") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(HomeFilter.values().toList()) { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { filter = f },
                        label = { Text(f.label) }
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            if (filteredRentals.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Активных аренд не найдено",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredRentals, key = { it.id }) { rental ->
                        RentalRow(
                            rental = rental,
                            bikeNumber = bikesById[rental.bikeId]?.number ?: "?",
                            renterName = rentersById[rental.renterId]?.fullName ?: "?",
                            onClick = { onOpenRental(rental.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsBar(
    totalBikes: Int,
    rentedCount: Int,
    freeCount: Int,
    repairCount: Int,
    dueTodayCount: Int,
    overdueCount: Int
) {
    val stats = listOf(
        Triple("🚲 Всего", totalBikes, MaterialTheme.colorScheme.onSurface),
        Triple("🔵 В аренде", rentedCount, StatusColors.Rented),
        Triple("🟢 Свободно", freeCount, StatusColors.Free),
        Triple("🟠 Ремонт", repairCount, StatusColors.Repair),
        Triple("🟡 Сегодня", dueTodayCount, StatusColors.DueSoon),
        Triple("🔴 Просрочено", overdueCount, StatusColors.Overdue)
    )
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(stats) { (label, value, color) ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(value.toString(), style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
                    Text(label, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun RentalRow(
    rental: RentalEntity,
    bikeNumber: String,
    renterName: String,
    onClick: () -> Unit
) {
    val daysLeft = DateUtils.daysUntil(rental.endDate)
    val statusColor = when {
        daysLeft <= 0 -> StatusColors.Overdue
        daysLeft <= 2 -> StatusColors.DueSoon
        else -> StatusColors.Free
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(width = 0.dp, color = Color.Transparent),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(48.dp)
                    .background(statusColor, RoundedCornerShape(3.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Велосипед № $bikeNumber", fontWeight = FontWeight.Bold)
                Text(renterName, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "До: ${DateUtils.formatDate(rental.endDate)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor
                )
            }
            Text(
                CurrencyUtils.formatRub(rental.price),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}
