package com.ebikerent.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.ebikerent.app.data.AppDatabase
import com.ebikerent.app.data.AppRepository
import com.ebikerent.app.notification.RentalCheckWorker
import com.ebikerent.app.ui.AppNavHost
import com.ebikerent.app.ui.theme.EbikeRentTheme

class MainActivity : ComponentActivity() {

    private lateinit var repository: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getInstance(applicationContext)
        repository = AppRepository(db)

        RentalCheckWorker.schedule(applicationContext)

        setContent {
            EbikeApp(repository)
        }
    }
}

@Composable
fun EbikeApp(repository: AppRepository) {
    val settings by repository.observeSettings().collectAsState(initial = null)
    val darkTheme = settings?.darkTheme

    EbikeRentTheme(
        darkTheme = darkTheme ?: androidx.compose.foundation.isSystemInDarkTheme()
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            AppNavHost(repository = repository)
        }
    }
}
